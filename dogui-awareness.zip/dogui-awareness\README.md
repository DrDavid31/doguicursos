# DOGUI Awareness

Plataforma estatica de concientizacion en ciberseguridad para empresas.

## Que incluye

- 3 planes comerciales: Basico, Profesional y Enterprise.
- Catalogo de cursos de ciberseguridad.
- Cursos por area: Finanzas, Recursos Humanos, Direccion y TI.
- Microcursos mensuales.
- Evaluacion rapida.
- Simulaciones de phishing para Enterprise.
- Reporte ejecutivo mensual.
- Reconocimiento PDF al aprobar la evaluacion.

## Como abrirlo

Abre `index.html` en tu navegador.

## Como subirlo a GitHub

1. Crea un repositorio nuevo en GitHub.
2. Sube estos archivos al repositorio:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `assets/`
   - `README.md`
3. Para publicarlo con GitHub Pages:
   - Entra a `Settings`.
   - Ve a `Pages`.
   - En `Source`, selecciona `Deploy from a branch`.
   - Selecciona la rama `main` y la carpeta `/root`.
   - Guarda los cambios.

## Estructura

```text
dogui-awareness/
  index.html
  styles.css
  app.js
  assets/
    awareness-dashboard.png
  README.md
```

## Notas

La plataforma esta hecha con HTML, CSS y JavaScript puro. No requiere instalar dependencias ni ejecutar backend.
